package mk.finki.ukim.mk.lab.repository.inMemory;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import mk.finki.ukim.mk.lab.model.Event;
import org.springframework.stereotype.Repository;

@Repository
public class InMemEventBookingRepository {

}
